import SwiftUI
import PlaygroundSupport
import AVFoundation
import UIKit
import Darwin

PlaygroundPage.current.setLiveView(Page0())

var player: AVAudioPlayer?
func playFirst() {
    guard let url = Bundle.main.url(forResource: "firstvoice", withExtension: "m4a") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
}

func Play2() {
    guard let url = Bundle.main.url(forResource: "Audio2", withExtension: "mp3") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
        player.volume=0.7
    } catch let error {
        print(error.localizedDescription)
    }
}

func Play3() {
    guard let url = Bundle.main.url(forResource: "Audio3", withExtension: "mp3") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
}

func Play4() {
    guard let url = Bundle.main.url(forResource: "Audio4", withExtension: "mp3") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
}

func Play5() {
    guard let url = Bundle.main.url(forResource: "Audio5", withExtension: "mp3") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
}

class MusicClass {
    static let shared = MusicClass()
    var audioPlayer = AVAudioPlayer()
    private init() {}
    func setup(){
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "music", ofType: "mp3")!))
            audioPlayer.prepareToPlay()
        } catch {
            print(error)
        }
    }
    
    func play() {
        audioPlayer.numberOfLoops = -1
        audioPlayer.play()
        audioPlayer.volume = 0.2
    }
    
    func stop() {
        audioPlayer.stop()
        audioPlayer.currentTime = 0
        audioPlayer.prepareToPlay()
    }
}

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//FUNZIONI SUONI
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
struct GradientButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .foregroundColor(Color.white)
            .background(LinearGradient(gradient: Gradient(colors: [Color.brown, Color.brown]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(8)
            .scaleEffect(configuration.isPressed ? 1.15 : 1.0)
    }
}

//PAGE 0
struct Page0: View{
    @State var scale = 1.5
    @State var scaleBack = 0.7
    @State private var opacity = 0.0
    @State var  muovi:CGFloat = 120
    @State var backAudio: AVAudioPlayer!
    var body: some View {
        ZStack{
                   Image(uiImage: UIImage(named: "copertina.png")!)
                                      .onAppear(){
                                              MusicClass.shared.setup()
                                              MusicClass.shared.play()
                                          }
                   VStack{
                       Image(uiImage: UIImage(named: "title.png")!)
                                   
                                        .resizable()
                                        .scaleEffect(scaleBack)
                                        .offset(y:75)
                                        .onAppear(){
                                            //DOPO x SECONDI AUMENTA L'OPACITA' A 1
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                                opacity=1}
                                               withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: true)){
                                                   scaleBack+=0.1}
                                            }
                   }
                                                     
                   Button {
                       PlaygroundPage.current.setLiveView(Page1())
                   } label:{
                       Text("START")
                           .padding(10)
                           .foregroundColor(.white)
                           .cornerRadius(100)
                           .opacity(opacity)
                   }
                   .buttonStyle(GradientButtonStyle())
                   .background(Color(.brown))
                   .cornerRadius(7)
                       .opacity(opacity)
                       .offset(y:260)
                   }
               }
}

//PAGE 1
struct Page1: View{
    
    @State var scale = 1.5
    @State var scaleBack = 1.5
    @State private var opacity = 0.0
    @State var  muovi:CGFloat = 120
    @State var backAudio: AVAudioPlayer!
    var body: some View {
        
     
        //__________________________________________VStack
        VStack{
            Text("Once upon a time, everything was quite in RecycleLand. The King and The Queen were reigning paecefully and all the villagers where living harmoniously in the     perfection    of the cleanliness of the Kingdom... But...")
                .offset(x: 10, y:400).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                    .transition(.opacity)
                
           //__________________________________________HStack
             HStack{
                Image(uiImage: UIImage(named: "prima500.png")!)
                     .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleBack)
                        .offset(x: 0, y:-55)
            }
            ZStack{
                
                Image(uiImage: UIImage(named: "nuvolo.png")!)
                        .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(1.0)
                        .offset(x:muovi, y:-400)
                        .onAppear() {
                            
                            //DOPO x SECONDI AUMENTA L'OPACITA' A 1
                            DispatchQueue.main.asyncAfter(deadline: .now() + 14) {
                                opacity=1}
                            
                            
                            playFirst()
                            
                            withAnimation(.linear(duration: 12)){
                            muovi -= 200
                                    
                           }
                        }
                
                //NEXT PAGE BUTTON
                Button {
                    PlaygroundPage.current.setLiveView(Page2())
                } label:{
                    Text("→")
                        .padding(10)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                        .opacity(opacity)
                }.buttonStyle(GradientButtonStyle())
                .offset(x:160, y:50)
                .zIndex(0)
                .opacity(opacity)
                .padding()
            }
            
        }
        
        .frame(width: 400, height: 700)
        .background(Color.black)
        
    }
}

//PAGE 2
struct Page2: View{
@State var scale = 1.0
@State var scaleBack = 1.5
@State var muovi:CGFloat = 120
@State var  muovistr:CGFloat = 120
@State var  muoviMNZ:CGFloat = 120
@State var  muoviSTRM:CGFloat = 195
@State var cadi:CGFloat = -460
@State var opacity = 0.0
    
    
    struct GradientButtonStyle: ButtonStyle {
        func makeBody(configuration: Self.Configuration) -> some View {
            configuration.label
                .foregroundColor(Color.white)
                
                .background(LinearGradient(gradient: Gradient(colors: [Color.brown, Color.brown]), startPoint: .leading, endPoint: .trailing))
                .cornerRadius(8)
                .scaleEffect(configuration.isPressed ? 1.15 : 1.0)
        }
    }
var body: some View {
    
    //__________________________________________VStack
    VStack{
        Text("One day all the villagers started to be worried about a big storm that was coming closer and closer. The storm was manned by witch Waste who wanted to conquer all the lands around and make them as dirty as she was. It was massive as far as the eye can see.")

            .offset(x: 10, y:425).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                .transition(.opacity)
            
       //__________________________________________HStack
         HStack{
            Image(uiImage: UIImage(named: "sfondo501.png")!)
                 .resizable()
                    //.scaledToFit()
                    .frame(width: 260, height: 260)
                    .scaleEffect(scaleBack)
                    .offset(x: 0, y:-55)
        }
        ZStack{
            
            Image(uiImage: UIImage(named: "strega.png")!)
                    .resizable()
                    //.scaledToFit()
                    .zIndex(1)
                    .frame(width: 260, height: 260)
                    .scaleEffect(1.0)
                    .offset(x:muovistr, y:-450)
                    .onAppear() {
                        withAnimation(.linear(duration: 12)){
                        muovistr -= 450
                       }
                    }

      
            
            Image(uiImage: UIImage(named: "waste.png")!)
                    .resizable()
                    //.scaledToFit()
                    .zIndex(2)
                    .frame(width: 260, height: 260)
                    .scaleEffect(0.6)
                    .offset(x:muoviMNZ+80, y:-460)
                    .onAppear() {
                        
                        withAnimation(.linear(duration: 12)){
                        muoviMNZ -= 450
                       }
                    }
            
            Image(uiImage: UIImage(named: "radioactive waste.png")!)
                    .resizable()
                    .scaleEffect(0.5)
                    .zIndex(0)
                    //.scaledToFit()
                    .frame(width: 260, height: 260)
                    .scaleEffect(0.6)
                    .offset(x:160, y:cadi)
                    .opacity(0.8)
                    .onAppear() {
                        Play2()
                    
                        withAnimation(.linear(duration: 3)){
                        cadi += 250
                       }
                    }
            
            Image(uiImage: UIImage(named: "storm.png")!)
                    .resizable()
                    //.scaledToFit()
                    .zIndex(-1)
                    .frame(width: 260, height: 260)
                    .scaleEffect(scale)
                    .animation(
                        .linear(duration: 2),
                        value: -100
                    )
                   .offset(x:muoviSTRM, y:-460)
                    .onAppear() {
                        //DOPO x SECONDI AUMENTA L'OPACITA' A 1
                        DispatchQueue.main.asyncAfter(deadline: .now() + 19) {
                            opacity=1}
                    
                        withAnimation(.linear(duration: 3).repeatForever(autoreverses: true)){
                            scale+=0.2
                            withAnimation(.linear(duration: 12)){
                                          muoviSTRM-=100
                       }
                    }
                    }
            //NEXT PAGE BUTTON
            Button {
                PlaygroundPage.current.setLiveView(Page3())
            } label:{
                Text("→")
                    .padding(10)
                    .foregroundColor(.white)
                    .cornerRadius(100)
                    .opacity(opacity)
            }.buttonStyle(GradientButtonStyle())
            .offset(x:160, y:50)
            .zIndex(0)
            .opacity(opacity)
            .padding()
        }
    }
    .frame(width: 400, height: 700)
    .background(Color.black)
}
}

//PAGE 3
struct Page3: View{
    @State var scale = 1.5
    @State var scaleBack = 1.5
    @State private var opacity = 0.0
    @State var muovi:CGFloat = 120
    @State var  muovistr:CGFloat = 120
    @State var  muoviMNZ:CGFloat = 120
    @State var  muoviSTRM:CGFloat = 195
    @State var  muoviPrincess:CGFloat = 120
    @State var cadi:CGFloat = -460
    
    var body: some View {
        
        //__________________________________________VStack
        VStack{
            Text("Suddenly, Princess Recycle was captured by the Witch Waste and brought away from the castle.")

                .offset(x: 10, y:425).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                    .transition(.opacity)
           
                
           //__________________________________________HStack
             HStack{
                Image(uiImage: UIImage(named: "sfondo502.png")!)
                     .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleBack)
                        .offset(x: 0, y:-55)
            }
            ZStack{
                
                Image(uiImage: UIImage(named: "strega.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(0.7)
                        .offset(x:muovistr, y:-180)
                        .onAppear() {
                            //DOPO x SECONDI AUMENTA L'OPACITA' A 1
                            DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
                                opacity=1}
                            Play3()
                            withAnimation(.linear(duration: 7)){
                            muovistr -= 450
                           }
                        }
                
              
                Image(uiImage: UIImage(named: "princess.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(1)
                        .offset(x:muoviPrincess-100, y:-190)
                        .onAppear(){
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                                withAnimation(.linear(duration: 7)){
                                muoviPrincess -= 450
                            }
                        }
                        }
                
                Image(uiImage: UIImage(named: "storm.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(scale-0.5)
                        .animation(
                            .linear(duration: 2),
                            value: -100
                        )
                       .offset(x:muoviSTRM-100, y:-440)
                        .onAppear() {
                        
                            withAnimation(.linear(duration: 3).repeatForever(autoreverses: true)){
                                scale+=0.2
                                withAnimation(.linear(duration: 12)){
                                              muoviSTRM-=30
                           }
                        }
                        }
                //NEXT PAGE BUTTON
                Button {
                    PlaygroundPage.current.setLiveView(Page4())
                } label:{
                    Text("→")
                        .padding(10)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                        .opacity(opacity)
                }.buttonStyle(GradientButtonStyle())
                .offset(x:160, y:50)
                .zIndex(0)
                .opacity(opacity)
                .padding()
            }
        }
        .frame(width: 400, height: 700)
        .background(Color.black)
    }
}

//PAGE 4
struct Page4: View{
    @State var scale = 1.5
    @State var scaleBack = 1.5
    @State private var opacity = 1.0
    @State var muovi:CGFloat = 120
    @State var  muovistr:CGFloat = 120
    @State var  muoviMNZ:CGFloat = 120
    @State var  muoviPrincess:CGFloat = 120
    @State var  muoviPrince:CGFloat = 120
    @State var cadi:CGFloat = -460
    @State var  muoviSTRM:CGFloat = 195
    @State var rotation = false
    @State var opacity1 = 0.0
    @State var scaleExpl = 0.7
    
    var body: some View {
        
        //__________________________________________VStack
        VStack{
            Text("Prince Rightbin was asked by the royals to save the princess and bring her back to the motherland. He begins his journey and reaches the witch. They fight hard and in the end the prince wins the battle and finally defeats the witch.")

                .offset(x: 10, y:425).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                    .transition(.opacity)
           
            
                
           //__________________________________________HStack
             HStack{
                Image(uiImage: UIImage(named: "sfondo503.png")!)
                     .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleBack)
                        .offset(x: 0, y:-55)
                        
                 
               
            }
            ZStack{
                
                Image(uiImage: UIImage(named: "stregaG.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(0.7)
                        .rotationEffect(rotation ? .zero : Angle.degrees(360))
                        .offset(x:muovistr-200, y:-170)
                        .onAppear() {
                            Play4()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 8.995) {
                    withAnimation(.linear(duration: 1)){
                            rotation = true
                            muovistr -= 450
                           }
                        }
                        }
                Image(uiImage: UIImage(named: "expl.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(3)
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleExpl)
                        .opacity(opacity1)
                        .offset(x:-40, y:-195)
                        .onAppear() {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 8.995) {
                                opacity1=1.0
                                withAnimation(.linear(duration: 0.1)){
                                    scaleExpl=1
                           }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    opacity1=0.0
                                }
                           }
                        
                        }

              
                Image(uiImage: UIImage(named: "prince.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(1)
                        .offset(x:muoviPrince-100, y:-190)
                        .onAppear(){
                            DispatchQueue.main.asyncAfter(deadline: .now() + 8.8) {
                                withAnimation(.linear(duration: 0.2)){
                                muoviPrince -= 70
                            }
                        }
                        }
                
                
                
                Image(uiImage: UIImage(named: "storm.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(scale-0.5)
                        .animation(
                            .linear(duration: 2),
                            value: -100
                        )
                       .offset(x:muoviSTRM-100, y:-440)
                        .onAppear() {
                        
                            withAnimation(.linear(duration: 3).repeatForever(autoreverses: true)){
                                scale+=0.2
                                withAnimation(.linear(duration: 12)){
                                              muoviSTRM-=30
                           }
                        
                        
                                
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                                        withAnimation(.linear(duration: 2)){
                                                      muoviSTRM+=1000
                                   }
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                            PlaygroundPage.current.setLiveView(Page5())
                                        }
                                        
                        }
                        }
                        }
                        
                //NEXT PAGE BUTTON
                Button {
                    PlaygroundPage.current.setLiveView(Page5())
                } label:{
                    Text("→")
                        .padding(10)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                        .opacity(0)
                }.buttonStyle(GradientButtonStyle())
                .offset(x:160, y:50)
                .zIndex(0)
                .opacity(0)
                .padding()
            }
        }
        .frame(width: 400, height: 700)
        .background(Color.black)
    }
}

func playWow() {
    guard let url = Bundle.main.url(forResource: "wow", withExtension: "mp3") else { return }
    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        guard let player = player else { return }
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
    
}

//PAGE 5
struct Page5: View{
    @State var scale = 1.5
    @State var scaleBack = 1.5
    @State private var opacity = 0.0
    @State var muovi:CGFloat = 120
    @State var  muovistr:CGFloat = 120
    @State var  muoviMNZ:CGFloat = 120
    @State var  muoviPrincess:CGFloat = 120
    @State var  muoviPrince:CGFloat = 120
    @State var cadi:CGFloat = -460
    @State var  muoviSTRM:CGFloat = 195
    @State var rotation = false
    @State var opacity1 = 0.0
    @State var scaleExpl = 0.7
    
    var body: some View {
        
        //__________________________________________VStack
        VStack{
            Text("...")

                .offset(x: 10, y:425).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                    .transition(.opacity)
           
            
                
           //__________________________________________HStack
             HStack{
                Image(uiImage: UIImage(named: "sfondo504.png")!)
                     .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleBack)
                        .offset(x: 0, y:-55)
                

            }
            ZStack{
            
                Image(uiImage: UIImage(named: "prince.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(3)
                        .offset(x:muoviPrince-170, y:-240)
                        .onAppear(){
                            playWow()
                            //DOPO x SECONDI AUMENTA L'OPACITA' A 1
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                opacity=1}
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                                withAnimation(.linear(duration: 1)){
                                muoviPrince -= 200
                                    
                                
                                }
                            }
                          
                        }
                
                        
                //NEXT PAGE BUTTON
                Button {
                    PlaygroundPage.current.setLiveView(Page6())
                } label:{
                    Text("→")
                        .padding(10)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                        .opacity(opacity)
                }.buttonStyle(GradientButtonStyle())
                .offset(x:160, y:50)
                .zIndex(0)
                .opacity(opacity)
                .padding()
            }
        }
        .frame(width: 400, height: 700)
        .background(Color.black)
    }
}

//PAGE 6
struct Page6: View{
    @State var scale = 1.5
    @State var scaleBack = 1.5
    @State private var opacity = 0.0
    @State var muovi:CGFloat = 120
    @State var  muovistr:CGFloat = 120
    @State var  muoviMNZ:CGFloat = 120
    @State var  muoviPrincess:CGFloat = 120
    @State var  muoviPrince:CGFloat = 120
    @State var cadi:CGFloat = -460
    @State var  muoviSTRM:CGFloat = 195
    @State var rotation = false
    @State var opacity1 = 0.0
    @State var scaleExpl = 0.7
    
    var body: some View {
        
        //__________________________________________VStack
        VStack{
            Text("Prince Rightbin returns to the castle and returns the princess back to her family to live happily ever after in the clean kingdom of Recycleland.")

                .offset(x: 10, y:425).foregroundColor(.white).font(.system(size: 15, weight: .light, design: .monospaced))
                    .transition(.opacity)
           
            
                
           //__________________________________________HStack
             HStack{
                Image(uiImage: UIImage(named: "sfondo505.png")!)
                     .resizable()
                        //.scaledToFit()
                        .frame(width: 260, height: 260)
                        .scaleEffect(scaleBack)
                        .offset(x: 0, y:-55)
                        .onAppear(){
                 Play5()
                        }
                

            }
            ZStack{
            
                Image(uiImage: UIImage(named: "princeR.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(3)
                        .frame(width: 260, height: 260)
                        .scaleEffect(2.3)
                        .offset(x:-120, y:-213)
                        .onAppear(){
                      
                        }
                
                Image(uiImage: UIImage(named: "king.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(1)
                        .offset(x:-42, y:-270)
                        .onAppear(){
                      
                        }
                
                Image(uiImage: UIImage(named: "queen.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(1)
                        .offset(x:16, y:-250)
                        .onAppear(){
                      
                        }
                
                Image(uiImage: UIImage(named: "princess.png")!)
                        .resizable()
                        //.scaledToFit()
                        .zIndex(-1)
                        .frame(width: 260, height: 260)
                        .scaleEffect(2.3)
                        .offset(x:muoviPrincess+200, y:-167)
                        .onAppear(){
                            //da cambiare a  +9
                            DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                                opacity=1}
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                                withAnimation(.linear(duration: 7)){
                                muoviPrincess -= 300
                            }
                        }
                        }
                
                //NEXT PAGE BUTTON
                Button {
                    PlaygroundPage.current.setLiveView(Page7())
                } label:{
                    Text("→")
                        .padding(10)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                        .opacity(opacity)
                }.buttonStyle(GradientButtonStyle())
                .offset(x:160, y:50)
                .zIndex(12)
                .opacity(opacity)
                .padding()
            }
        }
        .frame(width: 400, height: 700)
        .background(Color.black)
    }
}
//PAGE 7
struct Page7: View{
    @State var scale = 1.5
    @State var scaleBack = 0.5
    @State private var opacity = 1.0
    @State var  muovi:CGFloat = 120
    @State var backAudio: AVAudioPlayer!
    var body: some View {
        ZStack{
                   Image(uiImage: UIImage(named: "credits1.png")!)
                                      .onAppear(){
                                              MusicClass.shared.setup()
                                              MusicClass.shared.play()
                                              
                                      }
            
    
            
            
            
                   }
               }
}

